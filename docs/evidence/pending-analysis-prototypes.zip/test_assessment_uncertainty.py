import numpy as np
import pytest
from assessment_uncertainty import area_weights, projected_summary


def test_paired_projection_exactly_matches_direct_quadratic_area():
    rng = np.random.default_rng(43)
    budgets = [10, 15, 30]
    weights = area_weights(budgets)
    a, b = rng.normal(size=(2, 3, 4, 5, 7))
    treatments = rng.normal(size=(5, 8, 7))
    controls = rng.normal(size=(10, 7))
    truth = treatments.mean(axis=1) - controls.mean(axis=0)
    errors = np.mean((a - truth) ** 2 - (b - truth) ** 2, axis=(2, 3))
    direct = np.trapezoid(errors.mean(axis=1), budgets) / (budgets[-1] - budgets[0])
    coefficients = np.einsum("b,bsqg->qg", weights, a - b) / 4
    constants = np.einsum("b,bsq->q", weights, np.mean(a * a - b * b, axis=-1)) / 4
    t_projected = [treatments[i] @ coefficients[i] / 7 for i in range(5)]
    c_projected = controls @ coefficients.T / 7
    result = projected_summary(constants, t_projected, c_projected, samples=2000)
    assert result["paired_difference"] == pytest.approx(direct, abs=1e-14)


def test_shared_control_uncertainty_does_not_shrink_with_duplicate_query_loadings():
    rng = np.random.default_rng(44)
    control = rng.normal(size=100)
    constants = np.zeros(5)
    treatments = [np.zeros(20) for _ in constants]
    controls = np.tile(control[:, None], (1, 5))
    result = projected_summary(constants, treatments, controls, samples=20000)
    check = result["iid_measurement_variance_check"]
    assert check["shared_control_component"] == pytest.approx(4 * control.var(ddof=1) / 100)
    estimated = result["iid_cell_bootstrap_fixed_queries"]["resampling_standard_deviation"] ** 2
    assert estimated == pytest.approx(4 * control.var(ddof=0) / 100, rel=0.04)
    # An independent control resample per query would wrongly divide this by five.
    assert estimated > 4 * check["shared_control_component"] / 5


def test_fixed_strata_are_preserved_and_unknown_batches_are_unavailable():
    result = projected_summary(
        np.zeros(2),
        [np.array([0.0, 10.0])] * 2,
        np.tile(np.array([[0.0], [10.0]]), (1, 2)),
        samples=500,
        treatment_strata=[["a", "b"]] * 2,
        control_strata=["a", "b"],
        treatment_batches=[["", ""]] * 2,
        control_batches=["", ""],
    )
    strata = result["stratified_cell_bootstrap_fixed_queries"]
    assert strata["resampling_standard_deviation"] == 0
    assert strata["control_strata"]["singleton_strata"] == 2
    assert not result["batch_reweighting_sensitivity"]["available"]


def test_shared_batch_reweighting_cancels_identical_treatment_control_profiles():
    values = np.array([1.0, 1.0, 3.0, 3.0])
    result = projected_summary(
        np.zeros(2),
        [values] * 2,
        np.tile(values[:, None], (1, 2)),
        samples=1000,
        treatment_batches=[["a", "a", "b", "b"]] * 2,
        control_batches=["a", "a", "b", "b"],
    )
    batch = result["batch_reweighting_sensitivity"]
    assert batch["available"]
    assert batch["resampling_standard_deviation"] < 1e-14
